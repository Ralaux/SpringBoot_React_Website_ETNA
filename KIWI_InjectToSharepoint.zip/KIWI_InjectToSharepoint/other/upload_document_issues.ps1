﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy('http://internet-app.corp.thales:8000')


Import-Module ./modules/general_functions.psm1
Import-Module ./modules/metadata_process
Import-Module ./modules/connexion_sharepoint.psm1
Import-Module ./modules/entity_upload.psm1
Import-Module ./modules/entity_process.psm1

$flux = Get-Content "./config.json" | ConvertFrom-Json
$LibraryName = "Documents"
$proxyloginName = "AN007283"#$flux.proxyLoginName 
$secfile = "D:\Scripts\AN007283_scriptencryptedpassword_old.txt"#$flux.proxyEncryptedPasswordPath
$encrypted = Get-Content $secfile | ConvertTo-SecureString

Write-LogDebug -Content "Defining Proxy access"
if (!(Test-Path $secfile)) {
    Write-LogError "Input File NOT found"
    $credentialObject= Get-Credential -UserName $proxyloginName -Message "Enter Password"
    $credentialObject.password | ConvertFrom-SecureString | set-content $secfile
}
else
{
    [pscredential]$credentialObject = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $userlogin, $encrypted
    [System.Net.WebRequest]::DefaultWebProxy.Credentials = $credentialObject
}

#Set debug mode
if ($flux.debugMode -eq $false){
    $global:debug = $false
}elseIf ($flux.debugMode -eq $true){
    $global:debug = $true
}else{
    Write-LogError "Unknown debug mode!"
}

#DATA TO BE FILLED
#$configDoc = Get-Content "./other/upload_document_issues_config.json" -Encoding UTF8  | ConvertFrom-Json 
$configDoc = Get-Content  "./other/upload_document_issues_config.json"  | ConvertFrom-Json 

$nomSite = $configDoc.CommunityID
$SourceFolderPath =  $configDoc.SourceFileURL 
$FolderRelativeUrl = $configDoc.TargetFolderURL

$TenantUrl = "$($flux.tenantUrl)/sites/$($nomSite)"
$appid = $flux.appid
$appsecret = $flux.appsecret

Try
{
    $connection = Connect-PnPOnline -Url $TenantUrl -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop -ReturnConnection
    $Context = Get-PnPContext
#	-Connection $connection
}
Catch
{
    Write-LogError "Failed to connect : $( $_.Exception)"
    Write-LogError "Exiting...."
}

$Context, $Folder = loadFolder -Context $Context -LibraryName $LibraryName

$res = Add-PnPFile -Connection $connection -Folder $Folder.ServerRelativeUrl -FileName "Document Upload Issues.csv" -Content "FILE NAME, ORIGINAL PATH" 
#$res = Add-PnPFile -Connection $connection -Path "D:\\Scripts\\injectToSharepoint\\other\\Document Upload Issues.csv" -Folder $Folder.ServerRelativeUrl #-FileName "Document Upload Issues.csv" 


$uploadIssueFolder = $Folder.ServerRelativeURL + "/Upload Issue Document"
Write-LogDebug -Content "Ensuring Folder '$uploadIssueFolder' Exists for upload_document_issues script..."
$Context = RunUploadFolder -Context $Context -FolderRelativeURL $uploadIssueFolder -TargetFolder $Folder -connection $connection

For($i=0;$i -lt $SourceFolderPath.Count;$i++) 
{  
  #  $total =$FolderRelativeUrl[$i].Length+$metadata["$($flux.nodeName)"].Length
    
    #Write-host "BAM  $($FolderRelativeUrl[$i])"
    #Write-host "  "
    #if ($total -gt 400){
        
        $hashTable = @{}
        $metadata = @{}
        $documentObject = Get-Item $SourceFolderPath[$i]
        $SourceFolderRelativeURL = $SourceFolderPath[$i]+$documentObject.FullName.Replace($SourceFolderPath[$i],[string]::Empty)
        $fileJSON = "$SourceFolderRelativeURL\$($documentObject.Name).json"

        if (Test-Path $fileJSON -PathType leaf){
            $metadata = GetMetadata -file $fileJSON -metadata $metadata -flux $flux
        }

        $fileCategories = "$SourceFolderRelativeURL\$($documentObject.Name)"+"_categories.json"

        if (Test-Path $fileCategories -PathType leaf){
            $metadata = GetMetadata -file $fileCategories -metadata $metadata -flux $flux
        }

        $hashTable = UpdateHashTable -hashTable $hashTable -oldName $documentObject.Name -newName $metadata["$($flux.nodeName)"] 
    
    
        $item = $documentObject
        $TargetFolder = $Folder

        $Content = Get-PnPFile -Url "/sites/$($nomSite)/Shared Documents/Document Upload Issues.csv" -AsString -Connection $connection
        #Write-host "CONTENT  $($Content)"

        $updatedContent = "$($Content) 
        $($hashTable["$($metadata[$flux.dataID])"]), $($FolderRelativeUrl[$i])" 

        #Write-host "UPDATED CONTENT  $($updatedContent)"

        $res = Add-PnPFile -Connection $connection -Folder $Folder.ServerRelativeUrl -FileName "Document Upload Issues.csv" -Content $updatedContent 

        $Context = PreprocessVersions -Context $Context -metadata $metadata -item $item -TargetFolder $TargetFolder -connection $connection -FolderRelativeUrl $uploadIssueFolder <#$FolderRelativeUrl#> -flux $flux -normalizedName $hashTable["$($metadata[$flux.dataID])"]

   # }
    
}

