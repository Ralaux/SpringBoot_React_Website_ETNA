﻿$flux = Get-Content "./../config.json" | ConvertFrom-Json

$proxyloginName = $flux.proxyLoginName #"AN007283"
$secfile = $flux.proxyEncryptedPasswordPath #"D:\Scripts\AN007283_scriptencryptedpassword.txt" 

if (!(Test-Path $secfile)) {
    $credentialObject= Get-Credential -UserName $proxyloginName -Message "Enter Password"
    $credentialObject.password | ConvertFrom-SecureString | set-content $secfile
}