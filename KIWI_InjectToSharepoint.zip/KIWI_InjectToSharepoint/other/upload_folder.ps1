﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy('http://internet-app.corp.thales:8000')


Import-Module ./modules/general_functions.psm1
Import-Module ./modules/metadata_process
Import-Module ./modules/connexion_sharepoint.psm1
Import-Module ./modules/entity_upload.psm1
Import-Module ./modules/entity_process.psm1

$Error.Clear()

$flux = Get-Content "./config.json" | ConvertFrom-Json
$LibraryName = "Documents"
$proxyloginName = $flux.proxyLoginName 
$secfile = $flux.proxyEncryptedPasswordPath#"D:\Scripts\AN007283_scriptencryptedpassword_old.txt"#$flux.proxyEncryptedPasswordPath
$encrypted = Get-Content $secfile | ConvertTo-SecureString

Write-LogDebug -Content "Defining Proxy access"
if (!(Test-Path $secfile)) {
    Write-LogError "Input File NOT found"
    $credentialObject= Get-Credential -UserName $proxyloginName -Message "Enter Password"
    $credentialObject.password | ConvertFrom-SecureString | set-content $secfile
}
else
{
    [pscredential]$credentialObject = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $proxyloginName, $encrypted
    [System.Net.WebRequest]::DefaultWebProxy.Credentials = $credentialObject
}

#Set debug mode
if ($flux.debugMode -eq $false){
    $global:debug = $false
}elseIf ($flux.debugMode -eq $true){
    $global:debug = $true
}else{
    Write-LogError "Unknown debug mode!"
}

#DATA TO BE FILLED
$configDoc = Get-Content "./other/upload_folder_config.json" | ConvertFrom-Json

$nomSite = $configDoc.CommunityID
$SourceFolderPath =  $configDoc.SourceFileURL 
$FolderRelativeURLOrigin = "$($configDoc.TargetFolderURL)/"

$target = $FolderRelativeURLOrigin -split "Shared Documents"
$target = $target[1].Replace('/', '')

if ($configDoc.isIssue -eq "true"){
    $source = " "
}else{
    $sourceTmp = $SourceFolderPath -split "-$nomSite"
    $motAEnlever = $sourceTmp.Split("\\")[-1]
    $source = $sourceTmp[1] -split $motAEnlever
    $source = $source[0].Substring(0,$source[0].Length-1)
}

$TenantUrl = "$($flux.tenantUrl)/sites/$($nomSite)"
$appid = $flux.appid
$appsecret = $flux.appsecret

Try
{
    $connection = Connect-PnPOnline -Url $TenantUrl -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop -ReturnConnection
    $Context = Get-PnPContext
#	-Connection $connection
}
Catch
{
    Write-LogError "Failed to connect : $( $_.Exception)"
    Write-LogError "Exiting...."
}

$Context, $FolderDocuments = loadFolder -Context $Context -LibraryName $LibraryName
$Context = Get-PnPContext
#-Connection $connection
$Folder = $Context.Web.GetFolderByServerRelativeUrl($FolderRelativeURLOrigin)
$Context.Load($Folder)
$Context.ExecuteQuery()
$Context.Load($Context.Web)
$Context.ExecuteQuery()



$hashTable = @{}

For($I=0;$I -lt $source.count;$I++){
   $hashTable = UpdateHashTable -hashTable $hashTable -oldName $source[$I] -newName $target[$I]
} 

$TargetFolder = $Folder

$once = $true
Get-ChildItem  $SourceFolderPath -Recurse | ForEach-Object {
    $metadata = @{}
	$SourceFolderRelativeURL = $SourceFolderPath+$_.FullName.Replace($SourceFolderPath,[string]::Empty)
	$file = "$SourceFolderRelativeURL\$($_.Name).json"
    $Context = Get-PnPContext
#	-Connection $connection    
    $Error.Clear()
    if (Test-Path $file -PathType leaf)
    {
        $metadata = GetMetadata -file $file -metadata $metadata -flux $flux
        $subtype = $metadata["subtype"]

        If ($subtype -eq 3030329 -or $subtype -eq 3030331 -or $subtype -eq 0 -or $subtype -eq 136 -or  $subtype -eq 751 -or  $subtype -eq 3030202 -or $subtype -eq 5573){
            Try
            {
                $hashTable = UpdateHashTable -hashTable $hashTable -oldName $_.Name -newName $metadata["$($flux.nodeName)"]
                
                $FolderRelativeURL = $Folder.ServerRelativeUrl+$_.FullName.Replace($SourceFolderPath,[string]::Empty).Replace("\","/")
              
                $RelatifPathsNodes = $_.FullName.Replace($SourceFolderPath,[string]::Empty).Replace("\","/").split("/")
                $vide , $RelatifPathsNodesArray= $RelatifPathsNodes		
  
                foreach ($RelatifPathsNode in $RelatifPathsNodesArray) {
                    if ($hashTable.ContainsKey($RelatifPathsNode) -eq $true){   
                        $FolderRelativeURL = $FolderRelativeURL.Replace($RelatifPathsNode,$hashTable[$RelatifPathsNode])                      
                    }else{
                        $FolderRelativeURL = $FolderRelativeURL.Replace("/$RelatifPathsNode",'')
                    }
                } 

                If($FolderRelativeURL){
                    Write-LogDebug -Content "Ensuring Folder '$FolderRelativeURL' Exists from upload_folder script..."
      
	                #Check Folder Exists
                    Try {
                        $Folderr = $Context.Web.GetFolderByServerRelativeUrl($FolderRelativeURL)
                        $Context.Load($Folderr)
                        $Context.ExecuteQuery()
  
                        Write-LogInfo -Content "The folder $($FolderRelativeURL) already exists!"
                    }
                    Catch {
                        #Create New Sub-Folder
                        $Folderr = $Context.Web.Folders.Add($FolderRelativeURL)
                        $Context.ExecuteQuery()
		
                        Write-LogInfo -Content "Created Folder at $FolderRelativeURL"
                    }
                } 	
                
            }Catch
            {
                Write-LogError "Failed to preprocess the folder $($_.Name) : $( $_.Exception)"
            }
             
            if ($once -eq $true -and $configDoc.isIssue -eq "true"){

                $Content = Get-PnPFile -Url "/sites/$($nomSite)/Shared Documents/Document Upload Issues.csv" -AsString -Connection $connection
                $updatedContent = "$($Content) 
                $($hashTable["$($metadata[$flux.dataID])"]), $($configDoc.OriginalTargetFolderURL)" 
                $res = Add-PnPFile -Connection $connection -Folder "/sites/$($nomSite)/Shared Documents" -FileName "Document Upload Issues.csv" -Content $updatedContent 
                $once = $false
            }
            
          
            Write-LogInfo -Content "Folder '$SourceFolderRelativeURL' !"
        }ElseIf ($subtype -eq 144  -or $subtype -eq 5574 -or $subtype -eq 749 ){
            Try
            {
                $file = "$SourceFolderRelativeURL\$($_.Name)"+"_categories.json"

                if (Test-Path $file -PathType leaf){
                    $metadata = GetMetadata -file $file -metadata $metadata -flux $flux
                }

                $hashTable = UpdateHashTable -hashTable $hashTable -oldName $_.Name -newName $metadata["$($flux.nodeName)"] 

                $length_Dir = $_.Name.length
                $length_Path = $_.FullName.length
                $RelatifPaths = ($_.FullName).substring(0, $length_Path - $length_Dir - 1).Replace($SourceFolderPath,[string]::Empty)
                $RelatifPathsNodes = $RelatifPaths.Replace("\","/")		
                $RelatifPathsNodesArraySplit = $RelatifPathsNodes.split("/")
                $vide , $RelatifPathsNodesArray= $RelatifPathsNodesArraySplit
                $FolderRelativeUrl = $Folder.ServerRelativeURL +$RelatifPathsNodes

                foreach ($RelatifPathsNode in $RelatifPathsNodesArray) {
                    if ($hashTable.ContainsKey($RelatifPathsNode) -eq $true){
                        $FolderRelativeUrl = $FolderRelativeUrl.Replace("$RelatifPathsNode",$hashTable["$RelatifPathsNode"])
                    }else{
                        $FolderRelativeUrl = $FolderRelativeUrl.Replace("/$RelatifPathsNode",'')
                    }
                } 
                
                $lengthCh =$FolderRelativeUrl.Length+$metadata["$($flux.nodeName)"].Length

                if ($lengthCh -gt 400){
                    Write-LogDebug -Content "File path that exceeds 400 caraters, length = $($lengthCh) "
        
                    $uploadIssueFolder = "$($TargetFolder.ServerRelativeUrl)/Upload Issue Document"
                    $Content = Get-PnPFile -Url "$($TargetFolder.ServerRelativeUrl)/Document Upload Issues.csv" -AsString -Connection $connection
    
                    $updatedContent = "$($Content) 
                    $($hashTable["$($metadata[$flux.dataID])"]), $($FolderRelativeUrl)" 

                    $res = Add-PnPFile -Connection $connection -Folder $TargetFolder.ServerRelativeUrl -FileName "Document Upload Issues.csv" -Content $updatedContent 

                    $Context = PreprocessVersions -Context $Context -metadata $metadata -item $_ -TargetFolder $Folder -connection $connection -FolderRelativeUrl $uploadIssueFolder -flux $flux -normalizedName $hashTable["$($metadata[$flux.dataID])"]

                }else{
                    $Context = PreprocessVersions -Context $Context -metadata $metadata -item $_ -TargetFolder $Folder -connection $connection -FolderRelativeUrl $FolderRelativeUrl -flux $flux -normalizedName $hashTable["$($metadata[$flux.dataID])"]
                }

                #$Context = PreprocessVersions -Context $Context -metadata $metadata -item $_ -TargetFolder $Folder -connection $connection -FolderRelativeUrl $FolderRelativeUrl -flux $flux -normalizedName $hashTable["$($metadata[$flux.dataID])"]

                    
                if($Error.Count -ne 0)
                {
                    Write-LogError "$($Error)" 
                   
                }

                if ($configDoc.isIssue -eq "true"){
                    $originalRelativePath = $FolderRelativeUrl -split "Upload Issue Document"
                    $originalRelativePath = $originalRelativePath[-1]

                    $Content = Get-PnPFile -Url "/sites/$($nomSite)/Shared Documents/Document Upload Issues.csv" -AsString -Connection $connection
                    $updatedContent = "$($Content) 
                    $($hashTable["$($metadata[$flux.dataID])"]), $($configDoc.OriginalTargetFolderURL)$($originalRelativePath)" 
                    $res = Add-PnPFile -Connection $connection -Folder "/sites/$($nomSite)/Shared Documents" -FileName "Document Upload Issues.csv" -Content $updatedContent 
                }

                Write-LogInfo -Content "File '$SourceFolderRelativeURL' !"
                    
            }Catch{
                Write-LogError "Failed to preprocess the file $($_.Name) : $( $_.Exception)"
            }
        }
    }
}