﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

#[system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy('http://internet-app.corp.thales:8000')
#Get configuration
$flux = Get-Content "../config.json" | ConvertFrom-Json

#Proxy preparation and check
#$proxyloginName = "AN007283"#$flux.proxyLoginName 
#$secfile = "D:\Scripts\AN007283_scriptencryptedpassword_old.txt"#$flux.proxyEncryptedPasswordPath
#$encrypted = Get-Content $secfile | ConvertTo-SecureString



#[pscredential]$credentialObject = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $userlogin, $encrypted
#[System.Net.WebRequest]::DefaultWebProxy.Credentials = $credentialObject


$TenantUrl = $flux.tenantUrl
$TenantUser = $flux.tenantUser
#$appid = $flux.appid
#$appsecret = $flux.appsecret
$templateSiteURL = "https://sharepoint.corp.els/sites/elstemplatev01"
$SchmaXMLPath="$($flux.schmaXMLPath)"

Try
{
    Write-host "Connecting to tenant : $TenantUrl"
    #Connect-PnPOnline -Url $TenantUrl -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop
	#Connect-PnPOnline -Url $TenantUrl -Credential $Cred -WarningAction Ignore -ErrorAction Stop
    #Get-PnPContentTypePublishingHubUrl
    #Write-host "Connected to tenant : $TenantUrl"
}
Catch
{
    write-host "Exception : $( $_.Exception)"
    write-host "Failed to connect : Exiting"
    exit(9)
}

$Cred = Get-Credential -UserName $TenantUser -Message 'Enter Password'
#Connect-PnPOnline -Url $templateSiteURL -ClientId $appid -ClientSecret $appsecret
$connection = Connect-PnPOnline -Url $templateSiteURL -Credential $Cred -ReturnConnection
#echo $connection
#Connect-PnPOnline -Url $templateSiteURL -UseWebLogin
#Get-PnPSiteTemplate -Out ($SchmaXMLPath) -ListsToExtract "Documents","Identity Card" -PersistBrandingFiles –PersistPublishingFiles
Get-PnPProvisioningTemplate -Out ($SchmaXMLPath) -ListsToExtract "Documents","Identity Card" -PersistBrandingFiles –PersistPublishingFiles