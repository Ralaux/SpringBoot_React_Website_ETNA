﻿Import-Module pnp.powershell

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy('http://internet-app.corp.thales:8000')
#Get configuration
$flux = Get-Content "D:\Scripts\injectToSharepoint\config.json" | ConvertFrom-Json

#Proxy preparation and check
$proxyloginName = $flux.proxyLoginName 
$secfile = "D:\Scripts\AN007283_scriptencryptedpassword_old.txt"
$encrypted = Get-Content $secfile | ConvertTo-SecureString

if (!(Test-Path $secfile)) {
    $credentialObject= Get-Credential -UserName $proxyloginName -Message "Enter Password"
    $credentialObject.password | ConvertFrom-SecureString | set-content $secfile
}
else
{
    [pscredential]$credentialObject = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $userlogin, $encrypted
    [System.Net.WebRequest]::DefaultWebProxy.Credentials = $credentialObject
}


$TenantUrl = "https://urbanandmainlines.sharepoint.com"
$SiteAdmin = "https://urbanandmainlines-admin.sharepoint.com"
 
$appid = "eabaeed0-854d-471d-8c79-35ebcc079ead"
$appsecret = "D7I8Q~QvoxU3Vk.7-gY8xjWF~hvtw2.5Q7plUbK~"
 
$theuser="maria.solomon@aerow.fr"
$role="Owners"
$ListeSites = @("2021587","718886") 
#$myaction = "ADD"
$myaction = "REMOVE"
 

$ListeSites | ForEach-Object {
$siteURL = $TenantUrl +"/sites/" + $PSItem
$siteURL
$connection1 = Connect-PnPOnline -Url $siteURL -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop -ReturnConnection
$thegroup= Get-PnPGroup -Connection $connection1 | ? Title -Like '*Owners'
write-host $siteURL
write-host "$myaction $theuser in group  $($thegroup.Title)"
if ($myaction -eq "ADD")
{
    Add-PnPGroupMember -LoginName $theuser -Group $thegroup.Title -Connection $connection1
}
else
{
    Remove-PnPGroupMember -LoginName $theuser -Group $thegroup.Title -Connection $connection1
}
}