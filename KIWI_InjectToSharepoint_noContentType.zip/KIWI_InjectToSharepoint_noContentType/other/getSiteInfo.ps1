﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy('http://internet-app.corp.thales:8000')
 
$TenantUrl = "https://urbanandmainlines.sharepoint.com"
$SiteAdmin = "https://urbanandmainlines-admin.sharepoint.com"
 
$appid = "eabaeed0-854d-471d-8c79-35ebcc079ead"
$appsecret = "D7I8Q~QvoxU3Vk.7-gY8xjWF~hvtw2.5Q7plUbK~"
#Proxy preparation and check
$proxyloginName = "AN007283"#$flux.proxyLoginName 
$secfile = "D:\Scripts\AN007283_scriptencryptedpassword_old.txt"#$flux.proxyEncryptedPasswordPath
$encrypted = Get-Content $secfile | ConvertTo-SecureString

if (!(Test-Path $secfile)) {
    $credentialObject= Get-Credential -UserName $proxyloginName -Message "Enter Password"
    $credentialObject.password | ConvertFrom-SecureString | set-content $secfile
}
else
{
    [pscredential]$credentialObject = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $proxyloginName, $encrypted
    [System.Net.WebRequest]::DefaultWebProxy.Credentials = $credentialObject
} 


$connection1 = Connect-PnPOnline -Url $TenantUrl -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop -ReturnConnection
$allsites = Get-PnPTenantSite -Connection $connection1 -ErrorAction SilentlyContinue 
 
$ETOLSites = @()
$nbretotal = $allsites.Count
$i=0
foreach ($currentsite in $allsites)
{
    $i++
    $percent = [int]($i / $nbretotal *100)
    Write-Progress -Id 1 -Activity “Processing Sites” -Status "Site [$i/$nbretotal]" -PercentComplete $percent
 
    $siteid=$($currentsite.Url) -replace "https://urbanandmainlines.sharepoint.com/sites/" 
#    write-host $siteid
    if($siteid -match '^\d+$')
    {
        Connect-PnPOnline -Url $currentsite.Url -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop
        $siteadmins = Get-PnPSiteCollectionAdmin
        $isetol=$false
        foreach ($currentsiteadmin in $siteadmins)
        {
            if ($currentsiteadmin.Title -eq "AA-GLOBALDIR-G-S_WW_SPOSITEADMIN1 Members"){$isetol=$true}
 #           Write-host "$($currentsite.Url) : $($currentsiteadmin.Title)"
        }
 #       write-host "$($currentsite.Url)  ----> is from ETOL : $isetol"
        if($isetol)
        {
            $web=Get-PnPWeb -Includes Created
            $newetolste = new-object -TypeName PSObject
            if($web.Created -eq $null)
            {
                $Createddate = ""
            }
            else
            {
                $Createddate = $web.Created.ToString("MM/dd/yyyy")
            }
            if($currentsite.LastContentModifiedDate -eq $null)
            {
                $ModifiedDate = ""
            }
            else
            {
                $ModifiedDate = $currentsite.LastContentModifiedDate.ToString("MM/dd/yyyy")
            }

            $newetolste | Add-Member NoteProperty "COM_ID" "$siteid"
            $newetolste | Add-Member NoteProperty "SiteName" "$($currentsite.Title)"
            $newetolste | Add-Member NoteProperty "Url" "$($currentsite.Url)"
            $newetolste | Add-Member NoteProperty "Owner" "$($currentsite.Owner)"
            $newetolste | Add-Member NoteProperty "Created" "$($Createddate)"
            $newetolste | Add-Member NoteProperty "Modified" "$($ModifiedDate)"
            $newetolste | Add-Member NoteProperty "StorageUsage" "$($currentsite.StorageUsageCurrent)"
            $newetolste | Add-Member NoteProperty "StorageMaximumLevel" "$($currentsite.StorageQuotaWarningLevel)"
 
            $ETOLSites += $newetolste

        }
    }
}
 
$ETOLSites | Export-Csv -Path "D:\Scripts\injectToSharepoint\tests\SharepointSitesinfo.csv" -Delimiter ";" -Encoding UTF8 -NoTypeInformation -Force