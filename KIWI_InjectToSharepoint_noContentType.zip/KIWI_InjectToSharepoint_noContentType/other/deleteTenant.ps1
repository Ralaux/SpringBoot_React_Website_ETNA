[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy('http://internet-app.corp.thales:8000')
#Get configuration
$flux = Get-Content "./config.json" | ConvertFrom-Json

#Proxy preparation and check
$proxyloginName = "AN007283"#$flux.proxyLoginName 
$secfile = "D:\Scripts\AN007283_scriptencryptedpassword_old.txt"#$flux.proxyEncryptedPasswordPath
$encrypted = Get-Content $secfile | ConvertTo-SecureString

if (!(Test-Path $secfile)) {
    $credentialObject= Get-Credential -UserName $proxyloginName -Message "Enter Password"
    $credentialObject.password | ConvertFrom-SecureString | set-content $secfile
}
else
{
    [pscredential]$credentialObject = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $proxyloginName, $encrypted
    [System.Net.WebRequest]::DefaultWebProxy.Credentials = $credentialObject
}

$TenantUrl = $flux.tenantUrl
$SiteAdmin = "https://urbanandmainlines-admin.sharepoint.com"
 
$appid = $flux.appid
$appsecret = $flux.appsecret
$sitetodelete=$null
$deletedsite = $null

$configDoc = Get-Content "./other/deleteTenant_config.json" | ConvertFrom-Json
$siteid= "$($configDoc.CommunityID)"

 
$siteURL = $TenantUrl +"/sites/" + $siteid
# Connecting to tenant
 
$connection1 = Connect-PnPOnline -Url $TenantUrl -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop -ReturnConnection
$connection = Connect-PnPOnline -Url $SiteAdmin -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Stop -ReturnConnection


$sitetodelete = Get-PnPTenantSite -Identity $siteURL -Connection $connection -ErrorAction SilentlyContinue 
$deletedsite = Get-PnPTenantDeletedSite -Identity $siteURL -Connection $connection1 -ErrorAction SilentlyContinue
 
 

if($sitetodelete -eq $null)
{
    if($deletedsite -eq $null)
    {
        Write-host "$siteURL does NOT exist in tenant"
    }
    else
    {
        Write-host "$siteURL in recycle bin : let's purge it"
        Remove-PnPTenantSite -Url $siteURL -Force -FromRecycleBin -Verbose -Connection $connection -ErrorAction Stop
    }
}
else 
{
    Write-host "$siteURL existe : let's delete it and purge it"
    Remove-PnPTenantSite -Url $siteURL -Force -SkipRecycleBin -Verbose -Connection $connection -ErrorAction Stop
 
}