﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
#[system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy('http://internet-app.corp.thales:8000')

Import-Module ./modules/general_functions.psm1
Import-Module ./modules/connexion_sharepoint.psm1
Import-Module ./modules/launch_injection.psm1
Import-Module ./modules/entity_upload.psm1
Import-Module ./modules/metadata_process.psm1
Import-Module ./modules/entity_process.psm1


#Get configuration
$flux = Get-Content "./config.json" | ConvertFrom-Json

#Proxy preparation and check
#$proxyloginName = $flux.proxyLoginName 
#$secfile = $flux.proxyEncryptedPasswordPath
#$encrypted = Get-Content $secfile | ConvertTo-SecureString

Write-LogStart
#Write-LogDebug -Content "Defining Proxy access"
#if (!(Test-Path $secfile)) {
#    Write-LogError "Input File NOT found"
#    $credentialObject= Get-Credential -UserName $proxyloginName -Message "Enter Password"
#    $credentialObject.password | ConvertFrom-SecureString | set-content $secfile
#}
#else
#{
#    [pscredential]$credentialObject = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $proxyloginName, $encrypted
#    [System.Net.WebRequest]::DefaultWebProxy.Credentials = $credentialObject
#}

#Set debug mode
if ($flux.debugMode -eq $false){
    $global:debug = $false
}elseIf ($flux.debugMode -eq $true){
    $global:debug = $true
}else{
    Write-LogError "Unknown debug mode!"
}

#Set global variables from configuration
$TenantUrl = $flux.tenantUrl
# $TenantUser = $flux.tenantUser
#$appid = $flux.appid
#$appsecret = $flux.appsecret
$SourceFolderPath=$flux.sourceFolderPath
$SiteURL = $flux.siteURL

# Get global credentials
# $Cred = Get-Credential -UserName $TenantUser -Message 'Enter Password'

#Start global time
$startTimeGlobal =  Get-Date 

Write-LogInfo -Content "LogFile: $global:LogFile"

#Get all communitites from source folder 
Get-ChildItem $SourceFolderPath | ForEach-Object {
	Write-LogInfo -Content "Parsing folder $($_.FullName)"
    If ($_.PSIsContainer -eq $True)
    {
        $Error.Clear()

        #Check if community is extracted 
        if ($($_.Name).Split('_')[1] -eq "extracted"){
            $hashTable = @{}
            
            #Get community name
            $folderCommunity = Get-ChildItem -Path $_.FullName -Directory
            $metadataCommunity = "$($_.FullName)\$($folderCommunity.Name)\$($folderCommunity.Name).json"

            $communityName = Get-Content -Raw $metadataCommunity  -Encoding UTF8 | ConvertFrom-Json
            $communityName = $communityName.nodeName
     
            # #$NewSiteTechname =  $($_.Name).Split('_')[0]
			# $NewSiteTechname = $folderCommunity.Name.Substring(1)

            # #Get business owners for this community
            # $BusinessOwners =  $ownersTable[$NewSiteTechname]
            # #Set Owner of the site
            # if ($BusinessOwners -ne "" -and $BusinessOwners -ne $null){
            #     $Owner = $BusinessOwners[0]
            # }else{
            #     $Owner = $PrimaryOwner
            # }
            
            # Write-LogDebug -Content "Bussiness owners are $($BusinessOwners) "

            # #$NewsiteURL = $TenantUrl + "/sites/test-20230621-001_"+ $NewSiteTechname
			# $NewsiteURL = $TenantUrl + "/sites/prd"+ $NewSiteTechname
            $SourceFolderPathCommunity = $SourceFolderPath + $_.Name 
            $startTime =  Get-Date
       
            Write-LogInfo -Content "Injection in preparation $($NewSiteTechname) ..."

            # Try
            # {
            #     Write-LogDebug -Content "Connecting to tenant : $TenantUrl"
            #     $startdate=Get-Date
            #     #$connection = Connect-PnPOnline -Url $TenantUrl -ClientId $appid -ClientSecret $appsecret -WarningAction Ignore -ErrorAction Continue -ReturnConnection
			# 	$connection = Connect-PnPOnline -Url $TenantUrl -UseWebLogin -WarningAction Ignore -ErrorAction Continue -ReturnConnection
            #     $item1 = Get-PnPContentTypePublishingHubUrl -Connection $connection -WarningAction Ignore -ErrorAction Continue
            #     Get-Time -startdate $startdate -mode $Global:debug -content "Connect-pnponline :"
            #     Write-LogDebug -Content "Connected to tenant : $TenantUrl"
            #     Write-LogDebug -Content "Connexion : $connection"
            # }
            # Catch
            # {
            #     Write-LogError "Exception : $( $_.Exception)"
            #     Write-LogError "Failed to connect : Exiting"
            #     #Break script
            # }

            # if($Error.Count -ne 0)
            # {
            #     Write-LogError "Failed to connect : $Error" 
            #     Return
            # } 

            try
            {
                $startdate2=Get-Date
                Write-LogDebug -Content "Connecting to $SiteURL"
                Set-PnPTraceLog -On -LogFile "./logs/logs_site.txt" -Level Debug
                #$connection = Connect-PnPOnline -Url $NewsiteURL -ClientId $appid -ClientSecret $appsecret -ErrorAction Continue  -WarningAction Ignore
				# $connection = Connect-PnPOnline -Url $SiteURL -Credential $Cred -ErrorAction Continue -WarningAction Ignore
				$connection = Connect-PnPOnline -Url $SiteURL -UseWebLogin -ErrorAction Continue -WarningAction Ignore

				# AEROW ORD - COMMENT THIS WHEN TEMPLATE IS ALREADY APPLIED
				# $item3 = Apply-PnPProvisioningTemplate -Path $SchmaXMLPath -ClearNavigation -WarningAction Ignore -IgnoreDuplicateDataRowErrors -ErrorAction Continue -Verbose -Debug
                Get-Time -startdate $startdate2 -mode $Global:debug -content  "connected to $SiteURL"

            }
            catch
            {
                Write-LogError "error in site connection : $( $_.Exception)"
                Write-LogError "Exiting...."
                #Break script
                #Continue
            }

            if($Error.Count -ne 0)
            {
                Write-LogError "Abort current execution for $SiteURL : $Error" 
                Return
            } 
        
            Write-LogInfo -Content "Connected to $SiteURL"
            # AEROW ORD This instruction fails on SP 2019 since Identity is not known
			#$item4 =  Set-PnPTenantSite -Identity $NewsiteURL -StorageQuota $storagequota -Connection $connection
			# AEROW ORD This instruction fails on SP 2019 since HideTitleInHeader is not known
            #$item5 = Set-PnPWeb -HideTitleInHeader:$false  -Connection $connection
			# Add Owners on site
            # $item10 = Add-PnPUserToGroup -ErrorAction SilentlyContinue -LoginName "zeus\S999999" -Identity $OwnersGroup.LoginName
			
            $Context = Get-PnPContext 
			# -Connection $connection
            
            #$Context, $connection = InitConnexion -TenantUrl $NewsiteURL -appid $appid -appsecret $appsecret
            
            $item11 = LoopCommunity -Context $Context -SourceFolderPath $SourceFolderPathCommunity -NewSiteName $communityName -hashTable $hashTable -connection $connection -flux $flux

            Get-Time -startdate $startTime -mode "INFO" -content "Execution time per community:"
    
        }
    }
}

Get-Time -startdate $startTimeGlobal -mode "INFO" -content "Global execution time:"
Write-LogFinish