
$flux = Get-Content "./config.json" | ConvertFrom-Json

$SourceFolderPath=$flux.sourceFolderPath

Get-ChildItem $SourceFolderPath | ForEach-Object {
    if ($_.PSIsContainer -eq $True)
    {
        if ($($_.Name).Split('_')[1] -eq "extracted" -or $($_.Name).Split('_')[1] -eq "failed" -or $($_.Name).Split('_')[1] -eq "chorus"){
			$NbFiles = Get-ChildItem -Path $_.FullName -Recurse -filter "*-1.dat" | Measure-Object | %{$_.Count}
			$NbUploaded = Get-ChildItem -Path $_.FullName -Recurse -filter "*-uploaded.txt" | Measure-Object | %{$_.Count}
			echo "$($_.Name): $($NbUploaded) / $($NbFiles)"
		} elseif ($($_.Name).Split('_')[1] -eq "done") {
		}
	}
}
	